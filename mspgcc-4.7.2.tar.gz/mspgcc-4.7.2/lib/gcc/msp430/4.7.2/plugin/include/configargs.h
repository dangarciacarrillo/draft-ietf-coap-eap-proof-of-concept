/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.7.2/configure --target=msp430 --enable-languages=c --program-prefix=msp430- --prefix=/home/dgarcia/mspgcc-4.7.2";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
