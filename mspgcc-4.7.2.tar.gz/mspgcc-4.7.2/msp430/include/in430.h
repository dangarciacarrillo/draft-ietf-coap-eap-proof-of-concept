/* in430.h is an old IAR header, superseded by <intrinsics.h> */
#ifndef __MSP430_IN430_H_
#define __MSP430_IN430_H_
#include <intrinsics.h>
#endif /* __MSP430_IN430_H_ */
